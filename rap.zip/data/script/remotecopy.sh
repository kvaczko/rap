#!/bin/bash

current_date=$(date +"%Y%m%d")
current_datetime_log=$(date +"%Y/%m/%d %H:%M:%S")
logfile="/data/log/$current_date.log"
destination="kvaczko@192.168.101.11:~/Downloads/IRIS/"


touch $logfile

current_datetime_log=$(date +"%Y/%m/%d %H:%M:%S")
echo $current_datetime_log" remotecopy.sh      Remote copy script (remotecopy.sh)" >>$logfile

current_datetime_log=$(date +"%Y/%m/%d %H:%M:%S")
echo $current_datetime_log" remotecopy.sh      Copying files..." >>$logfile
scp /data/IRIS/* $destination >>$logfile 2>> $logfile

if [ $? -eq 0 ]; then
	current_datetime_log=$(date +"%Y/%m/%d %H:%M:%S")
	echo $current_datetime_log" remotecopy.sh        SCP completed successfully." >>$logfile
        echo $current_datetime_log" remotecopy.sh        Deleting files from /data/IRIS/" >>$logfile
	rm -fR /data/IRIS/* 2>> $logfile
        current_datetime_log=$(date +"%Y/%m/%d %H:%M:%S")
        echo $current_datetime_log" remotecopy.sh        Files deleted successfully." >>$logfile
else
        current_datetime_log=$(date +"%Y/%m/%d %H:%M:%S")
        echo $current_datetime_log" remotecopy.sh        SCP encountered an error. Exit status: $?" >>$logfile
fi

current_datetime_log=$(date +"%Y/%m/%d %H:%M:%S")
echo $current_datetime_log" remotecopy.sh      ...done." >>$logfile

echo $current_datetime_log" remotecopy.sh      Setting GPIO23 (MR-6400 power on/off relay) to OFF." >>$logfile

pinctrl set GPIO23 op dl


current_datetime_log=$(date +"%Y/%m/%d %H:%M:%S")
echo $current_datetime_log" remotecopy.sh      Remote copy script has finished. Exiting." >>$logfile
