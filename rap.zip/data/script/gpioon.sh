#!/bin/bash

current_date=$(date +"%Y%m%d")
current_datetime_log=$(date +"%Y/%m/%d %H:%M:%S")
logfile="/data/log/$current_date.log"

touch $logfile

current_datetime_log=$(date +"%Y/%m/%d %H:%M:%S")
echo $current_datetime_log" gpioon.sh          GPIO script (gpioon.sh)" >>$logfile
echo $current_datetime_log" gpioon.sh          Setting GPIO23 (MR-6400 power on/off relay) to ON." >>$logfile

pinctrl set GPIO23 op dh

echo $current_datetime_log" gpioon.sh          GPIO script has finished. Exiting." >>$logfile
