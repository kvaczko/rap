#!/bin/bash

sleep 1
current_date=$(date +"%Y%m%d")
current_datetime_log=$(date +"%Y/%m/%d %H:%M:%S")
logfile="/data/log/$current_date.log"

touch $logfile

current_datetime_log=$(date +"%Y/%m/%d %H:%M:%S")
echo $current_datetime_log" runcheck.sh        Run checker script (runcheck.sh)" >>$logfile

if pgrep -x "ffmpeg" >/dev/null
then
	current_datetime_log=$(date +"%Y/%m/%d %H:%M:%S")
	echo $current_datetime_log" runcheck.sh        FFMPEG is running. Nothing to do." >>$logfile
else
	current_datetime_log=$(date +"%Y/%m/%d %H:%M:%S")
	echo $current_datetime_log" runcheck.sh        FFMPEG is NOT running. Forcing start script." >>$logfile
	/bin/bash /data/script/encodestart.sh
fi
current_datetime_log=$(date +"%Y/%m/%d %H:%M:%S")
echo $current_datetime_log" runcheck.sh        Run checker script has finished. Exiting." >>$logfile
