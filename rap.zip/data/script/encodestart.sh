#!/bin/bash

current_date=$(date +"%Y%m%d")
current_datetime_log=$(date +"%Y/%m/%d %H:%M:%S")
logfile="/data/log/$current_date.log"
ffmpeglogfile="/data/log/ffmpeg.log"
configfile="/data/website/config.txt"
recordLength="00:00:50"

touch $logfile

current_datetime_log=$(date +"%Y/%m/%d %H:%M:%S")
echo $current_datetime_log" encodestart.sh     Encoder start script (encodestart.sh)" >>$logfile

if pgrep -x "ffmpeg" >/dev/null
then
	current_datetime_log=$(date +"%Y/%m/%d %H:%M:%S")
	echo $current_datetime_log" encodestart.sh     FFMPEG is running." >>$logfile
        current_datetime_log=$(date +"%Y/%m/%d %H:%M:%S")
	echo $current_datetime_log" encodestart.sh     Killing process..." >>$logfile
        kill -15 `pidof ffmpeg`
        current_datetime_log=$(date +"%Y/%m/%d %H:%M:%S")
	echo $current_datetime_log" encodestart.sh     ...done." >>$logfile
fi

current_datetime=$(date +"%Y%m%d-%H%M%S")

current_datetime_log=$(date +"%Y/%m/%d %H:%M:%S")
echo $current_datetime_log" encodestart.sh     Starting FFMPEG..." >>$logfile

if [ -f "$configfile" ]; then
  while IFS=' : ' read -r arg_name arg_value; do
      case $arg_name in
          radiofrequency)
              radiofrequency="$arg_value"
              ;;
          radiochannelname)
              channelName="$arg_value"
              ;;
          audiobitrate)
              audioBitrate="$arg_value"
              audioBitrate+="k"
              ;;
          samplerate)
              sampleRate="$arg_value"
              ;;
      esac
  done < "$configfile"
else
  current_datetime_log=$(date +"%Y/%m/%d %H:%M:%S")
  echo $current_datetime_log" encodestart.sh     Config file does not exist! Nothing to do!" >>$logfile
fi

output_file="/data/IRIS_temp/${channelName}-${current_datetime}.mkv"
current_datetime_log=$(date +"%Y/%m/%d %H:%M:%S")
echo $current_datetime_log" encodestart.sh     Config channel name:  "$channelName >>$logfile
echo $current_datetime_log" encodestart.sh     Config frequency:     "$radiofrequency >>$logfile
echo $current_datetime_log" encodestart.sh     Config audio bitrate: "$audioBitrate >>$logfile
echo $current_datetime_log" encodestart.sh     Config samplerate:    "$sampleRate >>$logfile
echo $current_datetime_log" encodestart.sh     Output filename:      "$output_file >>$logfile

arecord -r48000 -fS32_LE -c2 | ffmpeg -acodec pcm_s32le -i - -loop 1 -framerate 5 -i /data/config/background.png -f dshow -y -vf "yadif=0:-1:0, scale=96:72" -c:v libx264 -x264-params keyint=1 -preset superfast -b:v 50k -c:a libvorbis -b:a $audioBitrate -ar $sampleRate -pix_fmt yuv420p -t $recordLength -f matroska $output_file 2>>$ffmpeglogfile

current_datetime_log=$(date +"%Y/%m/%d %H:%M:%S")
echo $current_datetime_log" encodestart.sh     Recording has finished." >>$logfile

current_datetime_log=$(date +"%Y/%m/%d %H:%M:%S")
echo $current_datetime_log" encodestart.sh     Moving file from /data/IRIS_temp/ to /data/IRIS/" >>$logfile

mv /data/IRIS_temp/* /data/IRIS/ 2>> $logfile

current_datetime_log=$(date +"%Y/%m/%d %H:%M:%S")
echo $current_datetime_log" encodestart.sh     ...done." >>$logfile
current_datetime_log=$(date +"%Y/%m/%d %H:%M:%S")
echo $current_datetime_log" encodestart.sh     Encoder start script has finished. Exiting." >>$logfile


