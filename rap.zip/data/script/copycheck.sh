#!/bin/bash

current_date=$(date +"%Y%m%d")
current_datetime_log=$(date +"%Y/%m/%d %H:%M:%S")
logfile="/data/log/$current_date.log"

touch $logfile

current_datetime_log=$(date +"%Y/%m/%d %H:%M:%S")
echo $current_datetime_log" copycheck:      File retainer script (copycheck.sh)" >>$logfile

current_datetime_log=$(date +"%Y/%m/%d %H:%M:%S")
echo $current_datetime_log" copycheck:      Deleting files older than 15 days from /data/IRIS/..." >>$logfile

find "/data/IRIS/" -type f -mtime +15 -exec rm {} \;

current_datetime_log=$(date +"%Y/%m/%d %H:%M:%S")
echo $current_datetime_log" copycheck:      ...done." >>$logfile
current_datetime_log=$(date +"%Y/%m/%d %H:%M:%S")
echo $current_datetime_log" copycheck:      Deleting log files older than 90 days from /data/log/..." >>$logfile

find "/data/log/" -type f -mtime +90 -exec rm {} \;

current_datetime_log=$(date +"%Y/%m/%d %H:%M:%S")
echo $current_datetime_log" copycheck:      ...done." >>$logfile

current_datetime_log=$(date +"%Y/%m/%d %H:%M:%S")
echo $current_datetime_log" copycheck:      File retainer script has finished. Exiting." >>$logfile
