#!/bin/bash

current_date=$(date +"%Y%m%d")
current_datetime_log=$(date +"%Y/%m/%d %H:%M:%S")
logfile="/data/log/$current_date.log"

touch $logfile

current_datetime_log=$(date +"%Y/%m/%d %H:%M:%S")
echo $current_datetime_log" cfgchange.sh       Configuration change detector script (cfgchange.sh)" >>$logfile

if [ -e "/data/website/ok.txt" ]; then
    current_datetime_log=$(date +"%Y/%m/%d %H:%M:%S")
    echo $current_datetime_log" cfgchange.sh       Config change detected. Restarting encoder..." >>$logfile
    rm -f /data/website/ok.txt

    /data/script/encodestart.sh
    current_datetime_log=$(date +"%Y/%m/%d %H:%M:%S")
    echo $current_datetime_log" cfgchange.sh       ...done." >>$logfile
fi

current_datetime_log=$(date +"%Y/%m/%d %H:%M:%S")
echo $current_datetime_log" cfgchange.sh       Configuration change detector script has finished. Exiting." >>$logfile


