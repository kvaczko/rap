from flask import Flask, render_template, request, redirect, url_for, flash, jsonify
from flask_login import LoginManager, UserMixin, login_user, login_required, logout_user, current_user
from werkzeug.security import generate_password_hash, check_password_hash
import os
app = Flask(__name__)
app.config['SECRET_KEY'] = 'your_secret_key'
login_manager = LoginManager(app)

class User(UserMixin):
    def __init__(self, user_id, username, password, is_admin=False):
        self.id = user_id
        self.username = username
        self.password = password
        self.is_admin = is_admin

users = {
    1: User(1, 'admin', generate_password_hash('admin_password'), is_admin=True),
    2: User(2, 'operator', generate_password_hash('operator_password'), is_admin=False),
}
password_check = os.listdir()
if 'operator_password.txt' in password_check:
    pass
else:
    with open('operator_password.txt', 'w') as password_file:
        
        password_file.write(generate_password_hash('operator_password'))


@login_manager.user_loader
def load_user(user_id):
    return users.get(int(user_id))

@app.route('/')
def index():
    return render_template('login.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        remember = True if request.form.get('remember') else False
        user = next((user for user in users.values() if user.username == username), None)

        if not user.is_admin:
            with open('operator_password.txt', 'r') as password_file:
                stored_password = password_file.read()

            if check_password_hash(stored_password, password):
                login_user(user, remember=remember)
                return redirect(url_for('dashboard'))
            else:
                flash('Invalid username or password', 'error')
        else:
            if user and check_password_hash(user.password, password):
                login_user(user, remember=remember)
                return redirect(url_for('dashboard'))
            else:
                flash('Invalid username or password', 'error')

    return render_template('login.html')




@app.route('/dashboard')
@login_required
def dashboard():
    if current_user.is_admin:
        return redirect(url_for('reset_password_page'))
    return render_template('dashboard.html')

@app.route('/reset_password', methods=['GET', 'POST'])
def reset_password():
    if request.method == 'POST':


        return redirect(url_for('reset_password_page'))

    return render_template('reset_password.html')

@app.route('/reset_password_page', methods=['GET', 'POST'])
def reset_password_page():
    if request.method == 'POST':
        new_password = request.form['password1']
        confirm_password = request.form['password2']

        if new_password == confirm_password:
            user = users.get(int(2))
            user.password = generate_password_hash(new_password)
            flash('Password successfully changed for Operator!', 'success')
        else:
            flash('Passwords do not match. Please enter matching passwords.', 'error')

        return redirect(url_for('reset_password_page'))

    return render_template('reset_password.html')

@app.route('/save_settings', methods=['POST'])
def save_settings():
    try:
        if 'config.txt' in os.listdir():
            os.remove('config.txt')
        data = request.get_json()
        radiofrequency = 'radiofrequency' ' : ' + data['radiofrequency']
        radiochannelname = 'radiochannelname' ' : ' + data['radiochannelname']
        audiobitrate = 'audiobitrate' ' : ' + data['recordingparameters']['audiobitrate']
        samplerate = 'samplerate' ' : ' + data['recordingparameters']['samplerate']
        radio_list = [radiofrequency,radiochannelname,audiobitrate,samplerate]
        for i in range(len(radio_list)):
            file = open('config.txt', 'a+')
            file.write('{}\n'.format(str(radio_list[i]).replace('(','').replace(')','')))
            file.close()

        with open('ok.txt', 'w') as ok_file:
            ok_file.write("OK")

        response = {'status': 'success'}
    except Exception as e:
        response = {'status': 'error', 'message': str(e)}

    return jsonify(response)


@app.route('/logout')
@login_required
def logout():
    logout_user()
    return redirect(url_for('index'))

if __name__ == '__main__':
    app.run(host='0.0.0.0',port=5050)
